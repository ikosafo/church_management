<?php

date_default_timezone_set('UTC');
$datetime = date("Y-m-d H:i:s");
$mysqli = new mysqli('localhost:3308', 'root', 'root', 'pharm');

if ($mysqli->connect_errno) {
    echo "cannot connect MYSQLI error no{$mysqli->connect_errno}:{$mysqli->connect_errno}";
    exit();
}


//Get Logo
function getLogo()
{
    global $mysqli;
    $getlogo = $mysqli->query("select * from system_config LIMIT 1");
    $reslogo = $getlogo->fetch_assoc();
    return $reslogo['logo'];
}

//Get Company Name
function getCompanyName()
{
    global $mysqli;
    $getcomname = $mysqli->query("select * from system_config LIMIT 1");
    $rescomname = $getcomname->fetch_assoc();
    return $rescomname['companyname'];
}

//Get Company Tagline
function getCompanyTagline()
{
    global $mysqli;
    $getcomname = $mysqli->query("select * from system_config LIMIT 1");
    $rescomname = $getcomname->fetch_assoc();
    return $rescomname['tagline'];
}

//Get Company Address
function getCompanyAddress()
{
    global $mysqli;
    $getcomname = $mysqli->query("select * from system_config LIMIT 1");
    $rescomname = $getcomname->fetch_assoc();
    return $rescomname['address'];
}

//Get Company Telephone
function getCompanyTelephone()
{
    global $mysqli;
    $getcomname = $mysqli->query("select * from system_config LIMIT 1");
    $rescomname = $getcomname->fetch_assoc();
    return $rescomname['telephone'];
}

session_start();
