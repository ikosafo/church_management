/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 8.0.18 : Database - pos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pos`;

/*Table structure for table `categories` */

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `catid` int(12) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(200) DEFAULT NULL,
  `categorycode` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `useraction` varchar(200) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `categories` */

insert  into `categories`(`catid`,`categoryname`,`categorycode`,`datetime`,`useraction`,`status`) values (1,'Confectionary','CN','2022-04-08 06:26:55','',0),(4,'Beverage','BV','2022-04-08 06:28:22','ikosafo',NULL),(9,'Health','HS','2022-04-16 06:00:36','ikosafo',0),(15,'','','2022-05-09 06:37:56','ikosafo',NULL),(13,'Sanitizers','SN','2022-04-16 10:42:41','ikosafo',NULL);

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `cusid` int(12) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) DEFAULT NULL,
  `emailaddress` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(200) DEFAULT NULL,
  `gender` varchar(200) DEFAULT NULL,
  `companyname` varchar(200) DEFAULT NULL,
  `nationality` varchar(200) DEFAULT NULL,
  `residence` varchar(200) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `adinfo` varchar(250) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`cusid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `customer` */

insert  into `customer`(`cusid`,`fullname`,`emailaddress`,`phonenumber`,`gender`,`companyname`,`nationality`,`residence`,`address`,`adinfo`,`status`) values (1,'Eunice Appiah Pokuaa','euniceappiah@gmail.com','0248278723','Female','IEPharm Ltd','Ghanaian','Ga Odumase','321, Accra','More info',NULL),(2,'Eunice Appiah','','0551336924','Female','Phersons Pharmacy','Ghanaian','Israel Yellow House','121, Accra','',0),(6,'Prince Appiah','princeappiah@gmail.com','0208237822','Male','Shell Petroleum','Ghanaian','Ga Odumase','321, Accra','',NULL),(4,'Emma Perry','','0202376723','Male','IEPharm','Ghanaian','Tantra Hills','23, Lapaz','A great customer',0);

/*Table structure for table `expcategories` */

DROP TABLE IF EXISTS `expcategories`;

CREATE TABLE `expcategories` (
  `expcatid` int(12) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(200) DEFAULT NULL,
  `categorycode` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `useraction` varchar(200) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`expcatid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `expcategories` */

insert  into `expcategories`(`expcatid`,`categoryname`,`categorycode`,`datetime`,`useraction`,`status`) values (1,'Electricity','EL','2022-04-28 17:45:24','ikosafo',NULL),(3,'Wa','WB','2022-04-28 17:58:40','ikosafo',0),(4,'Water Bill','WB','2022-04-29 05:53:00','ikosafo',NULL),(5,'Goods','GD','2022-04-30 16:26:59','ikosafo',NULL);

/*Table structure for table `expenses` */

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `expid` int(12) NOT NULL AUTO_INCREMENT,
  `expdate` date DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `paymentmode` varchar(200) DEFAULT NULL,
  `expcatid` int(12) DEFAULT NULL,
  `receipient` varchar(200) DEFAULT NULL,
  `approvedby` varchar(200) DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`expid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `expenses` */

insert  into `expenses`(`expid`,`expdate`,`amount`,`paymentmode`,`expcatid`,`receipient`,`approvedby`,`reason`,`description`,`user`,`datetime`,`status`) values (1,'2022-04-27',5000.00,'Cash',5,'EI Company','Yaw Adu','Purchase of goods','','ikosafo','2022-04-30 16:27:46',NULL),(2,'2022-04-30',200.00,'Cash',1,'ECG','Babara','Electricity Bills','It got finished','ikosafo','2022-04-30 17:09:30',0);

/*Table structure for table `giftcard` */

DROP TABLE IF EXISTS `giftcard`;

CREATE TABLE `giftcard` (
  `giftid` int(12) NOT NULL AUTO_INCREMENT,
  `giftnumber` varchar(200) DEFAULT NULL,
  `giftvalue` varchar(200) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `customerid` int(12) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`giftid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `giftcard` */

insert  into `giftcard`(`giftid`,`giftnumber`,`giftvalue`,`description`,`customerid`,`status`,`datetime`) values (1,'324324242','230','Christmas Bonuses',4,0,NULL),(2,'231232131','500','sdas',1,0,NULL),(3,'31234332424','1200','Christmas bonus',1,NULL,'2022-04-28 07:59:21');

/*Table structure for table `invoices` */

DROP TABLE IF EXISTS `invoices`;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62110 DEFAULT CHARSET=latin1;

/*Data for the table `invoices` */

/*Table structure for table `logs` */

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `logid` int(12) NOT NULL AUTO_INCREMENT,
  `logdate` datetime DEFAULT NULL,
  `section` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `message` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `macaddress` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ipaddress` varchar(200) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `logs` */

insert  into `logs`(`logid`,`logdate`,`section`,`message`,`user`,`macaddress`,`ipaddress`,`action`) values (156,'2022-05-05 03:34:38','User','Add User error (Username already exists)','ikosafo','Host Name . . . .','::1','Failed'),(157,'2022-05-05 03:34:56','User','Added product Pepsodent as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(155,'2022-05-03 09:06:35',NULL,'Added dsa as subcategory successfully','ikosafo','Host Name . . . .','::1','Successful'),(154,'2022-05-03 06:28:59','Supplier','Supplier Isaac Osafo from Levels Inc was added successfully','ikosafo','Host Name . . . .','::1','Successful'),(153,'2022-05-01 00:53:12','Customer','Update Customer details for Eunice Appiah Pokuaa successfully','ikosafo','Host Name . . . .','::1','Successful'),(152,'2022-05-01 00:52:42','Customer','Deleted customer Emma Perry successfully','ikosafo','Host Name . . . .','::1','Successful'),(151,'2022-05-01 00:51:57','Customer','Customer Prince Appiah was added successfully','ikosafo','Host Name . . . .','::1','Successful'),(150,'2022-05-01 00:50:36','Login','ikosafo logged in Successfully','ikosafo','Host Name . . . .','::1','Successful'),(158,'2022-05-05 04:16:22','User','Added product sadasd as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(159,'2022-05-05 04:24:11','User','Added product asd as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(160,'2022-05-06 02:31:22','User','Add User error (Username already exists)','ikosafo','Host Name . . . .','::1','Failed'),(161,'2022-05-06 02:31:35','User','Added product asdas as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(162,'2022-05-06 02:39:55','User','Added product Testagain as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(163,'2022-05-06 02:49:50','User','Added product asdas as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(164,'2022-05-06 03:49:00','Product','Deleted product asd successfully','ikosafo','Host Name . . . .','::1','Successful'),(165,'2022-05-06 03:49:07','Product','Deleted product asdas successfully','ikosafo','Host Name . . . .','::1','Successful'),(166,'2022-05-06 03:49:10','Product','Deleted product sadasd successfully','ikosafo','Host Name . . . .','::1','Successful'),(167,'2022-05-06 06:37:54','User','Add User error (Username already exists)','ikosafo','Host Name . . . .','::1','Failed'),(168,'2022-05-06 06:39:06','User','Add User error (Username already exists)','ikosafo','Host Name . . . .','::1','Failed'),(169,'2022-05-06 09:01:57','User','Added product asdasdas as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(170,'2022-05-06 09:02:51','Product','Add Product error (Barcode already exists)','ikosafo','Host Name . . . .','::1','Failed'),(171,'2022-05-06 09:03:05','User','Added product asdasd as product successfully','ikosafo','Host Name . . . .','::1','Successful'),(172,'2022-05-06 09:04:44','Customer','Update Customer details for  successfully','ikosafo','Host Name . . . .','::1','Successful'),(173,'2022-05-06 09:10:50','Customer','Update Customer details for  successfully','ikosafo','Host Name . . . .','::1','Successful'),(174,'2022-05-06 09:17:28','Product','Update Product details by ikosafo successfully','ikosafo','Host Name . . . .','::1','Successful'),(175,'2022-05-06 09:20:54','Product','Update Product details by ikosafo successfully','ikosafo','Host Name . . . .','::1','Successful'),(176,'2022-05-06 09:21:16','Product','Update Product details by ikosafo successfully','ikosafo','Host Name . . . .','::1','Successful'),(177,'2022-05-08 04:12:09','Product','Update Product details by ikosafo successfully','ikosafo','Host Name . . . .','::1','Successful'),(178,'2022-05-08 04:12:27','Product','Update Product details by ikosafo successfully','ikosafo','Host Name . . . .','::1','Successful'),(179,'2022-05-09 06:37:56','Product Category','Added  as Product Category successfully','ikosafo','Host Name . . . .','::1','Successful'),(180,'2022-05-09 06:38:00',NULL,'Add Category error (Name or code already exists)','ikosafo','Host Name . . . .','::1','Failed'),(181,'2022-05-11 06:12:11','Product Category','ikosafo sold 1754.00 of items successfully','ikosafo','Host Name . . . .','::1','Successful'),(182,'2022-05-11 07:30:55','Product Category','ikosafo sold 1754.00 of items successfully','ikosafo','Host Name . . . .','::1','Successful'),(183,'2022-05-11 07:31:53','Product Category','ikosafo sold 246.00 of items successfully','ikosafo','Host Name . . . .','::1','Successful');

/*Table structure for table `messages` */

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `mesid` int(12) NOT NULL AUTO_INCREMENT,
  `receipient` varchar(200) DEFAULT NULL,
  `message` varchar(250) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`mesid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `messages` */

insert  into `messages`(`mesid`,`receipient`,`message`,`datetime`,`user`) values (1,'Everyone','Hello everyone, good morning and welcome to work','2022-04-24 05:17:54','ikosafo'),(2,'Administrator','This is a message','2022-05-01 00:09:01','ikosafo'),(3,'Developer','System is slow','2022-05-01 00:09:32','ikosafo');

/*Table structure for table `product_categories` */

DROP TABLE IF EXISTS `product_categories`;

CREATE TABLE `product_categories` (
  `pcatid` int(12) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`pcatid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `product_categories` */

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `prodid` int(12) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(250) DEFAULT NULL,
  `productname` varchar(250) DEFAULT NULL,
  `quantitysale` decimal(20,0) DEFAULT NULL,
  `quantitystock` decimal(20,0) DEFAULT NULL,
  `stockthreshold` decimal(20,0) DEFAULT NULL,
  `sku` varchar(250) DEFAULT NULL,
  `supplier` int(12) DEFAULT NULL,
  `expirydate` date DEFAULT NULL,
  `isbn` varchar(250) DEFAULT NULL,
  `category` int(12) DEFAULT NULL,
  `subcategory` int(12) DEFAULT NULL,
  `variation1` int(12) DEFAULT NULL,
  `variation1spec` varchar(200) DEFAULT NULL,
  `variation2` int(12) DEFAULT NULL,
  `variation2spec` varchar(200) DEFAULT NULL,
  `variation3` int(12) DEFAULT NULL,
  `variation3spec` varchar(200) DEFAULT NULL,
  `costprice` decimal(20,2) DEFAULT NULL,
  `sellingprice` decimal(20,2) DEFAULT NULL,
  `sellingpricewhole` decimal(20,2) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`prodid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `products` */

insert  into `products`(`prodid`,`barcode`,`productname`,`quantitysale`,`quantitystock`,`stockthreshold`,`sku`,`supplier`,`expirydate`,`isbn`,`category`,`subcategory`,`variation1`,`variation1spec`,`variation2`,`variation2spec`,`variation3`,`variation3spec`,`costprice`,`sellingprice`,`sellingpricewhole`,`username`,`datetime`,`status`) values (1,'12312312312','Pepsodent',12,21,22,'12',1,'2022-05-18','sdsad',4,1,1,'Red',2,'Small',1,'Blue',122.21,221.00,131.00,'ikosafo','2022-05-05 03:34:56',NULL),(2,'6970822190033','Marker',131,13,123,'asd',1,'0000-00-00','',4,1,1,'asdas',2,'sdasda',0,'',1231.00,1312.00,0.00,'ikosafo','2022-05-05 04:16:22',NULL),(3,'8901315201927','Ice Cream',131,13,131,'1a',1,'0000-00-00','',4,1,1,'Small',2,'sdasda',0,'',1232.00,123.00,0.00,'ikosafo','2022-05-05 04:24:11',NULL),(4,'132312312','Drug',123,131,123,'',1,'0000-00-00','',4,5,1,'Small',0,'',0,'',131.00,1312.00,0.00,'ikosafo','2022-05-06 02:31:35',NULL),(5,'23412312321','Testagain',33,12,12,'sd',0,'2022-05-24','asdas',4,1,1,'Small',2,'asds',0,'',1312.00,1312.00,0.00,'ikosafo','2022-05-06 02:39:55',NULL),(6,'12312312','Tooth paste',40,20,10,'12',1,'2022-05-07','N/a',4,5,1,'White',2,'Small',0,'',10.00,13.00,0.00,'ikosafo','2022-05-06 02:49:50',NULL),(7,'8901645060997','Soap',13,131,312,'',0,'2022-06-10','asd',4,1,1,'red',2,'Small',0,'',122.21,221.00,0.00,'ikosafo','2022-05-06 09:01:57',NULL),(8,'8906009233482','Pen',123,1223,13,'asd',1,'2022-05-06','asd',4,1,1,'Small',0,'',0,'',1231.00,1312.00,0.00,'ikosafo','2022-05-06 09:03:05',NULL);

/*Table structure for table `sales` */

DROP TABLE IF EXISTS `sales`;

CREATE TABLE `sales` (
  `salesid` int(12) NOT NULL AUTO_INCREMENT,
  `amountpaid` decimal(20,2) DEFAULT NULL,
  `totalprice` decimal(20,2) DEFAULT NULL,
  `change` decimal(20,2) DEFAULT NULL,
  `newsaleid` varchar(250) DEFAULT NULL,
  `customerid` int(12) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`salesid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `sales` */

insert  into `sales`(`salesid`,`amountpaid`,`totalprice`,`change`,`newsaleid`,`customerid`,`paymentmethod`,`username`,`datetime`) values (1,1800.00,1754.00,46.00,'2022051106114219',0,'cash','ikosafo','2022-05-11 06:12:11'),(2,1800.00,1754.00,46.00,'202205110612127',1,'cash','ikosafo','2022-05-11 07:30:55'),(3,300.00,246.00,54.00,'202205110730554',6,'cash','ikosafo','2022-05-11 07:31:53');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `stid` int(12) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `gender` varchar(150) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `telephone` varchar(200) DEFAULT NULL,
  `emailaddress` varchar(200) DEFAULT NULL,
  `residence` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `educationallevel` varchar(200) DEFAULT NULL,
  `idtype` varchar(150) DEFAULT NULL,
  `idnumber` varchar(200) DEFAULT NULL,
  `hometown` varchar(200) DEFAULT NULL,
  `generatedid` varchar(200) DEFAULT NULL,
  `staffid` varchar(200) DEFAULT NULL,
  `nationality` varchar(200) DEFAULT NULL,
  `position` varchar(200) DEFAULT NULL,
  `religion` varchar(200) DEFAULT NULL,
  `passportpic` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`stid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `staff` */

insert  into `staff`(`stid`,`fullname`,`gender`,`birthdate`,`telephone`,`emailaddress`,`residence`,`address`,`image`,`educationallevel`,`idtype`,`idnumber`,`hometown`,`generatedid`,`staffid`,`nationality`,`position`,`religion`,`passportpic`,`username`,`password`,`status`) values (7,'Eunice Appiah','Female','2022-04-19','0551336924','','Yellow House','12 Kumasi',NULL,'Bachelors','Voters','13123232','Kumasi Asafo','62022-04-20','PS129','Ghanaian','Teller','Christianity',NULL,'ikosafo2','e10adc3949ba59abbe56e057f20f883e',NULL),(6,'Isaac Osafo','Male','1990-10-19','0205737464','ikosafo@gmail.com','Ga Odumase','122, Accra',NULL,'Bachelors','Drivers License','123123222','Kwahu Akwasiho','92022-04-20','PS12','Ghanaian','Software Engineer','Christianity',NULL,'ikosafo','311c8cb5a6fa7d80a0c3b4f2f09ab179',NULL);

/*Table structure for table `staff_images` */

DROP TABLE IF EXISTS `staff_images`;

CREATE TABLE `staff_images` (
  `imgid` int(12) NOT NULL AUTO_INCREMENT,
  `imageloc` varchar(200) DEFAULT NULL,
  `random` varchar(200) DEFAULT NULL,
  `imagetype` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `staff_images` */

insert  into `staff_images`(`imgid`,`imageloc`,`random`,`imagetype`) values (1,'uploads/2022042158648.png','92022-04-20','image/png'),(2,'uploads/2022042130834.png','62022-04-20','image/jpeg');

/*Table structure for table `subcategories` */

DROP TABLE IF EXISTS `subcategories`;

CREATE TABLE `subcategories` (
  `subcatid` int(12) NOT NULL AUTO_INCREMENT,
  `subcategoryname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `subcategorycode` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `useraction` varchar(200) DEFAULT NULL,
  `parentid` int(12) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`subcatid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `subcategories` */

insert  into `subcategories`(`subcatid`,`subcategoryname`,`subcategorycode`,`datetime`,`useraction`,`parentid`,`status`) values (1,'Toffee','TF','2022-04-16 14:05:19','ikosafo',4,NULL),(2,'Pepsodent','PS','2022-04-16 14:22:59','ikosafo',9,NULL),(3,'Bandages','BN','2022-04-16 14:23:14','ikosafo',9,NULL),(5,'Drink','BT','2022-04-16 17:18:45','ikosafo',4,NULL),(6,'Cotton','CN','2022-04-17 05:57:54','ikosafo',1,NULL),(8,'dsa','asdas','2022-05-03 09:06:35','ikosafo',9,NULL);

/*Table structure for table `supplier` */

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `supid` int(12) NOT NULL AUTO_INCREMENT,
  `companyname` varchar(200) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `emailaddress` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `accnumber` varchar(200) DEFAULT NULL,
  `accbalance` decimal(10,0) DEFAULT NULL,
  `adinfo` varchar(250) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`supid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `supplier` */

insert  into `supplier`(`supid`,`companyname`,`fullname`,`emailaddress`,`phonenumber`,`city`,`address`,`accnumber`,`accbalance`,`adinfo`,`user`,`datetime`,`status`) values (1,'Levels Inc','Isaac Osafo','ikosafo@gmail.com','0202938928','Accra','113, East Legon','32132131222',12,'asdsad','ikosafo','2022-05-03 06:28:59',NULL);

/*Table structure for table `system_config` */

DROP TABLE IF EXISTS `system_config`;

CREATE TABLE `system_config` (
  `sysid` int(12) NOT NULL AUTO_INCREMENT,
  `companyname` varchar(200) DEFAULT NULL,
  `tagline` varchar(200) DEFAULT NULL,
  `logo` varchar(200) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `telephone` varchar(200) DEFAULT NULL,
  `currency` varchar(150) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `sysconid` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sysid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `system_config` */

insert  into `system_config`(`sysid`,`companyname`,`tagline`,`logo`,`address`,`telephone`,`currency`,`username`,`password`,`sysconid`) values (12,'Shell Petroleum','We serve the best','uploads/2022042366453.png','121, Accra','0551336924','GHS - Ghanaian Cedi - GH₵','ikosafo','311c8cb5a6fa7d80a0c3b4f2f09ab179','102022-04-05');

/*Table structure for table `tempsales` */

DROP TABLE IF EXISTS `tempsales`;

CREATE TABLE `tempsales` (
  `tsid` int(12) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(250) DEFAULT NULL,
  `quantity` int(12) DEFAULT NULL,
  `price` decimal(20,2) DEFAULT NULL,
  `genid` varchar(200) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `prodid` int(12) DEFAULT NULL,
  PRIMARY KEY (`tsid`)
) ENGINE=MyISAM AUTO_INCREMENT=282 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `tempsales` */

insert  into `tempsales`(`tsid`,`barcode`,`quantity`,`price`,`genid`,`datetime`,`prodid`) values (280,'12312312312',3,663.00,'202205111158387','2022-05-11 11:58:44',1),(279,'8901315201927',2,246.00,'202205110730554','2022-05-11 07:31:13',3),(278,'8901645060997',2,442.00,'202205110612127','2022-05-11 07:30:43',7),(277,'8906009233482',1,1312.00,'202205110612127','2022-05-11 07:30:37',8),(276,'8906009233482',1,1312.00,'2022051106114219','2022-05-11 06:11:54',8),(275,'8901645060997',2,442.00,'2022051106114219','2022-05-11 06:11:50',7),(274,'8901645060997',1,221.00,'2022051105420919','2022-05-11 05:42:18',7),(273,'8901315201927',1,123.00,'2022051105410912','2022-05-11 05:41:16',3),(272,'8901315201927',1,123.00,'2022051105351620','2022-05-11 05:35:30',3),(271,'8901645060997',4,884.00,'2022051105351620','2022-05-11 05:35:26',7),(270,'8906009233482',1,1312.00,'2022051105351620','2022-05-11 05:35:21',8),(269,'8901315201927',3,369.00,'202205110520231','2022-05-11 05:20:26',3),(268,'8901315201927',1,123.00,'202205110519147','2022-05-11 05:19:18',3),(267,'8901315201927',1,123.00,'2022051105185211','2022-05-11 05:18:57',3),(266,'8901315201927',1,123.00,'202205110517279','2022-05-11 05:17:30',3),(265,'8901645060997',2,442.00,'2022051105141017','2022-05-11 05:14:20',7),(264,'8906009233482',1,1312.00,'2022051105141017','2022-05-11 05:14:14',8),(263,'8901315201927',1,123.00,'202205110500386','2022-05-11 05:11:16',3),(262,'12312312312',1,221.00,'2022051105002820','2022-05-11 05:00:34',1),(261,'132312312',1,1312.00,'202205110459455','2022-05-11 04:59:53',4),(260,'8901315201927',1,123.00,'202205110458499','2022-05-11 04:58:52',3),(259,'8901315201927',2,246.00,'202205110458272','2022-05-11 04:58:30',3),(258,'12312312312',1,221.00,'202205110449414','2022-05-11 04:49:45',1),(257,'12312312312',2,442.00,'2022051104463519','2022-05-11 04:46:41',1),(256,'12312312312',1,221.00,'202205110445243','2022-05-11 04:45:29',1),(255,'8901315201927',1,123.00,'202205110442152','2022-05-11 04:42:24',3),(254,'12312312312',3,663.00,'202205110442152','2022-05-11 04:42:19',1),(252,'8901315201927',3,369.00,'2022051104404816','2022-05-11 04:40:51',3),(251,'12312312312',1,221.00,'2022051104400517','2022-05-11 04:40:08',1),(250,'23412312321',1,1312.00,'2022051104352020','2022-05-11 04:36:46',5),(249,'8901315201927',1,123.00,'2022051104352020','2022-05-11 04:35:24',3),(248,'6970822190033',2,2624.00,'202205110432509','2022-05-11 04:33:00',2),(247,'8901315201927',1,123.00,'202205110432509','2022-05-11 04:32:54',3),(242,'12312312',5,65.00,'2022051104204614','2022-05-11 04:20:56',6),(246,'6970822190033',1,1312.00,'2022051104204614','2022-05-11 04:22:52',2),(240,NULL,1,13.00,'202205110415361','2022-05-11 04:15:57',6),(239,NULL,1,1312.00,'202205110415361','2022-05-11 04:15:48',5),(238,'8901315201927',1,13.00,'202205110415361','2022-05-11 04:15:38',3);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  `role` varchar(10) NOT NULL,
  `brief` longtext NOT NULL,
  `image` varchar(250) NOT NULL,
  `op_text` varchar(250) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`password`,`mobile`,`status`,`role`,`brief`,`image`,`op_text`,`created`) values (1,'Aakash','aakash1234singhal@gmail.com','f07c010b6d605f93008f868133124b2d',8373929090,'Activate','admin','','1566138847_A12A664E-7A6E-4017-9C41-DADA5EC42D33.jpeg','Aakash@1234','2019-05-15 00:00:00'),(3,'gaurav singhal','gssinghal88@gmail.com','d5c6560eeca368b9fcb983593e2b483f',9999095558,'Activate','cashier','','','Dl3cck6545','2019-05-17 10:56:13'),(6,'KUNAL','KUNALSAGAR305@GMAIL.COM','ee257b0c7ec94c5c0e70f9c5704bfab6',9818964157,'Activate','cashier','','','92689392','2019-05-19 11:01:08'),(7,'Abhinav','er.abhinavgarg17@gmail.com','0f9b552222d2e020032a312f3e83d448',9457421088,'Activate','cashier','','','9457421088','2019-05-24 11:58:01'),(8,'SHWETA SINGHAL','GINNIGAURAVSINGHAL@GMAIL.COM','4082d57e73356263833a2a5243e189cb',8860329405,'Activate','cashier','','','Dl3cck6545#','2019-07-30 08:04:24'),(9,'RAJEEV PAL','RAJEEVPAL7054462963@GMAIL.COM','bff89daff47d5fd9da56a845e9d37059',7054462963,'Activate','cashier','','','70544629','2019-09-03 09:29:54');

/*Table structure for table `variations` */

DROP TABLE IF EXISTS `variations`;

CREATE TABLE `variations` (
  `varid` int(12) NOT NULL AUTO_INCREMENT,
  `attributename` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `attributecode` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `useraction` varchar(200) DEFAULT NULL,
  `status` int(12) DEFAULT NULL,
  PRIMARY KEY (`varid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `variations` */

insert  into `variations`(`varid`,`attributename`,`attributecode`,`datetime`,`useraction`,`status`) values (1,'Colour','CL','2022-04-18 00:57:16','ikosafo',NULL),(2,'Size','SZ','2022-04-18 00:58:49','ikosafo',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
