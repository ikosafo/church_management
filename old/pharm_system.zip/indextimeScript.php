<?php
  //date_default_timezone_set('Asia/Kolkata');
  echo $runningTime = date('l, F j - H:i:s');
?>